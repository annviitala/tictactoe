var tictactoeArray = []
let readlineSync = require('readline-sync')
var tileValue = [' - ', ' X ', ' O ']
var winnerCount = ['human1', 'human2', 'computer', 'draw']
let min = 3
let inputCheck = true
let rowNumber = min
let columnNumber = min
let numberPiecesToWin = min
winnerCount['human1'] = 0
winnerCount['human2'] = 0
winnerCount['computer'] = 0
winnerCount['draw'] = 0
// loop that validates the value provided by the user and return error message
while (inputCheck === true) {
  inputCheck = false
  console.log('=====================================')
  console.log('| Welcome to Ann\'s Tictactoe Game! |')
  console.log('=====================================')
  console.log('\n')
  rowNumber = readlineSync.questionInt('Enter number of rows : ')
  columnNumber = readlineSync.questionInt('Enter number of columns : ')
  numberPiecesToWin = readlineSync.questionInt('How many winning pieces must be next to each other to win : ')
  console.log('\n')
  if (rowNumber < min) {
    console.log('Minimun number of rows is (3) three!')
    console.log('\n')
    inputCheck = true
  } else if (columnNumber < min) {
    console.log('Minimun number of columns is (3) three!')
    console.log('\n')
    inputCheck = true
  } else if (numberPiecesToWin < min) {
    console.log('Minimun number of correct tiles is (3) three!')
    console.log('\n')
    inputCheck = true
  } else if ((columnNumber > rowNumber) || (rowNumber > columnNumber)) {
    console.log('The number of rows and columns must be the same example [3 X 3]!')
    console.log('\n')
    inputCheck = true
  } else if ((numberPiecesToWin > rowNumber) || (numberPiecesToWin > columnNumber)) {
    console.log('Correct tiles must NOT be GREATER than row numbers/column numbers!!')
    console.log('\n')
    inputCheck = true
  }
}
// function that creates the first board
function CreateInitialBoard (rowNumber, columnNumber) {
  let value = ' - '
  for (let i = 0; i < rowNumber; i++) {
    tictactoeArray[i] = []
    for (let j = 0; j < columnNumber; j++) {
      tictactoeArray[i][j] = value
    }
  }
}
/* function to validate number of pieces to win */
function PiecesToWin (piecesFromRow, piecesFromColumn, tictactoeArray, diagonalFromRight, diagonalFromLeft, numberPiecesToWin) {
  let firstfield = tictactoeArray[piecesFromRow][piecesFromColumn]
  if (firstfield === ' - ') {
    return false
  }
  for (let i = 0; i < numberPiecesToWin; i++) {
    let x = piecesFromColumn + diagonalFromLeft * i
    let y = piecesFromRow + diagonalFromRight * i
    if (tictactoeArray[y][x] !== firstfield) {
      return false
    }
  }
  return true
}
/* function that checks the winner */
function CheckWinner (tictactoeArray) {
  // checking winning column
  for (let x = 0; x < tictactoeArray.length; x++) {
    if (PiecesToWin(x, 0, tictactoeArray, 0, 1, numberPiecesToWin)) {
      return true
    }
  }
  // checking winning row
  for (let y = 0; y < tictactoeArray.length; y++) {
    if (PiecesToWin(0, y, tictactoeArray, 1, 0, numberPiecesToWin)) {
      return true
    }
  }
  // checking winning diagonal
  if (PiecesToWin(0, 0, tictactoeArray, 1, 1, numberPiecesToWin)) {
    return true
  }
  // checking winning diagonal
  if (PiecesToWin(2, 0, tictactoeArray, -1, 1, numberPiecesToWin)) {
    return true
  }
  return 'yes'
}
// function for first human player's turn
function Player1Turn (tictactoeArray) {
  let playerInputRow = 0
  let playerInputColumn = 0
  let inputCheck = true
  while (inputCheck === true) {
    inputCheck = false
    console.log('\n')
    console.log('First human player\'s turn')
    playerInputRow = readlineSync.questionInt('Choose a row position : ')
    playerInputColumn = readlineSync.questionInt('Choose a column position : ')
    console.log('\n')
    if ((playerInputRow >= rowNumber) || (playerInputColumn >= columnNumber)) {
      console.log('Invalid row/column position!')
      console.log('\n')
      inputCheck = true
    } else if (tictactoeArray[playerInputRow][playerInputColumn] === tileValue[0]) {
      tictactoeArray[playerInputRow][playerInputColumn] = tileValue[1]
    } else {
      inputCheck = true
    }
  }
  return console.log(tictactoeArray)
}
// function for second player's turn
function Player2Turn (tictactoeArray) {
  let playerInputRow = 0
  let playerInputColumn = 0
  let inputCheck = true
  while (inputCheck === true) {
    inputCheck = false
    console.log('\n')
    console.log('Second human player\'s turn')
    playerInputRow = readlineSync.questionInt('Choose a row/column position : ')
    playerInputColumn = readlineSync.questionInt('Choose a column position : ')
    console.log('\n')
    if ((playerInputRow >= rowNumber) || (playerInputColumn >= columnNumber)) {
      console.log('Invalid row/column position!')
      console.log('\n')
      inputCheck = true
    } else if (tictactoeArray[playerInputRow][playerInputColumn] === tileValue[0]) {
      tictactoeArray[playerInputRow][playerInputColumn] = tileValue[2]
    } else {
      inputCheck = true
    }
  }
  return console.log(tictactoeArray)
}
// function for the computer's turn
function ComputerTurn (tictactoeArray, rowNumber, columnNumber) {
  let computerInputRow = 0
  let computerInputColumn = 0
  let inputCheck = true
  console.log('Computer\'s turn')
  while (inputCheck === true) {
    inputCheck = false
    computerInputRow = Math.floor(Math.random() * rowNumber)
    computerInputColumn = Math.floor(Math.random() * columnNumber)
    if (tictactoeArray[computerInputRow][computerInputColumn] === tileValue[0]) {
      tictactoeArray[computerInputRow][computerInputColumn] = tileValue[2]
    } else {
      inputCheck = true
    }
  }
  return console.log(tictactoeArray)
}
// function to determine board is full and no winner
function BoardIsFull (tictactoeArray, rowNumber, columnNumber) {
  for (let i = 0; i < rowNumber; i++) {
    for (let j = 0; j < columnNumber; j++) {
      if (tictactoeArray[i][j] === tileValue[0]) {
        return false
      }
    }
  }
  return 'yes'
}

function PlayWithFriend () {
  CreateInitialBoard(rowNumber, columnNumber)
  do {
    Player1Turn(tictactoeArray)
    CheckWinner(tictactoeArray)
    BoardIsFull(tictactoeArray, rowNumber, columnNumber)
    if (CheckWinner(tictactoeArray) !== 'yes') {
      winnerCount['human1']++
      Human1Msg()
      break
    } else if ((BoardIsFull(tictactoeArray, rowNumber, columnNumber) === 'yes') && (CheckWinner(tictactoeArray) !== 'yes')) {
      winnerCount['human1']++
      Human1Msg()
      break
    } else if ((BoardIsFull(tictactoeArray, rowNumber, columnNumber) === 'yes')) {
      winnerCount['draw']++
      DrawMsg2()
      break
    }
    Player2Turn(tictactoeArray, rowNumber, columnNumber)
    CheckWinner(tictactoeArray)
    BoardIsFull(tictactoeArray, rowNumber, columnNumber)
    if (CheckWinner(tictactoeArray) !== 'yes') {
      winnerCount['human2']++
      Human2Msg()
      break
    } else if ((BoardIsFull(tictactoeArray, rowNumber, columnNumber) === 'yes') && (CheckWinner(tictactoeArray) !== 'yes')) {
      winnerCount['human2']++
      Human2Msg()
      break
    } else if ((BoardIsFull(tictactoeArray, rowNumber, columnNumber) === 'yes')) {
      winnerCount['draw']++
      DrawMsg2()
      break
    }
  } while (CheckWinner(tictactoeArray) === 'yes')
  return true
}
function PlayWithComputer1 () {
  CreateInitialBoard(rowNumber, columnNumber)
  do {
    Player1Turn(tictactoeArray)
    CheckWinner(tictactoeArray)
    BoardIsFull(tictactoeArray, rowNumber, columnNumber)
    if (CheckWinner(tictactoeArray) !== 'yes') {
      winnerCount['human1']++
      Human1Msg()
      break
    } else if ((BoardIsFull(tictactoeArray, rowNumber, columnNumber) === 'yes') && (CheckWinner(tictactoeArray) !== 'yes')) {
      winnerCount['human1']++
      Human1Msg()
      break
    } else if ((BoardIsFull(tictactoeArray, rowNumber, columnNumber) === 'yes')) {
      winnerCount['draw']++
      DrawMsg1()
      break
    }
    ComputerTurn(tictactoeArray, rowNumber, columnNumber)
    CheckWinner(tictactoeArray)
    BoardIsFull(tictactoeArray, rowNumber, columnNumber)
    if (CheckWinner(tictactoeArray) !== 'yes') {
      winnerCount['computer']++
      ComputerMsg()
      break
    } else if ((BoardIsFull(tictactoeArray, rowNumber, columnNumber) === 'yes') && (CheckWinner(tictactoeArray) !== 'yes')) {
      winnerCount['computer']++
      ComputerMsg()
      break
    } else if ((BoardIsFull(tictactoeArray, rowNumber, columnNumber) === 'yes')) {
      winnerCount['draw']++
      DrawMsg1()
      break
    }
  } while (CheckWinner(tictactoeArray) === 'yes')
  return true
}
function PlayWithComputer2 () {
  CreateInitialBoard(rowNumber, columnNumber)
  do {
    ComputerTurn(tictactoeArray, rowNumber, columnNumber)
    CheckWinner(tictactoeArray)
    BoardIsFull(tictactoeArray, rowNumber, columnNumber)
    if (CheckWinner(tictactoeArray) !== 'yes') {
      winnerCount['computer']++
      ComputerMsg()
      break
    } else if ((BoardIsFull(tictactoeArray, rowNumber, columnNumber) === 'yes') && (CheckWinner(tictactoeArray) !== 'yes')) {
      winnerCount['computer']++
      ComputerMsg()
      break
    } else if ((BoardIsFull(tictactoeArray, rowNumber, columnNumber) === 'yes')) {
      winnerCount['draw']++
      DrawMsg1()
      break
    }
    Player1Turn(tictactoeArray)
    CheckWinner(tictactoeArray)
    BoardIsFull(tictactoeArray, rowNumber, columnNumber)
    if (CheckWinner(tictactoeArray) !== 'yes') {
      winnerCount['human1']++
      Human1Msg()
      break
    } else if ((BoardIsFull(tictactoeArray, rowNumber, columnNumber) === 'yes') && (CheckWinner(tictactoeArray) !== 'yes')) {
      winnerCount['human1']++
      Human1Msg()
      break
    } else if ((BoardIsFull(tictactoeArray, rowNumber, columnNumber) === 'yes')) {
      winnerCount['draw']++
      DrawMsg1()
      break
    }
  } while (CheckWinner(tictactoeArray) === 'yes')
  return true
}
// function that displays draw message
function DrawMsg1 () {
  console.log('It\'s a draw!')
  console.log('Human player: ' + winnerCount['human1'])
  console.log('Computer: ' + winnerCount['computer'])
  console.log('Draw: ' + winnerCount['draw'])
}
// function that displays draw message
function DrawMsg2 () {
  console.log('It\'s a draw!')
  console.log('Human player: ' + winnerCount['human1'])
  console.log('Computer: ' + winnerCount['human2'])
  console.log('Draw: ' + winnerCount['draw'])
}
// function that displays winning message for player 1
function Human1Msg () {
  console.log('Congratulations, human player1 won!')
  console.log('Human player: ' + winnerCount['human1'])
  console.log('Computer: ' + winnerCount['computer'])
  console.log('Draw: ' + winnerCount['draw'])
}
// function that displays winning message for player 2
function Human2Msg () {
  console.log('Congratulations, human player1 won!')
  console.log('Human player: ' + winnerCount['human1'])
  console.log('Computer: ' + winnerCount['human2'])
  console.log('Draw: ' + winnerCount['draw'])
}
// function that display winnining message for computer
function ComputerMsg () {
  console.log('Congratulations, computer won!')
  console.log('Human player: ' + winnerCount['human1'])
  console.log('Computer: ' + winnerCount['computer'])
}
// function that displays players choices of action
function GameStart () {
  console.log('\n')
  console.log('==================================')
  console.log('|Let\'s play Ann\'s TIC TAC TOE!   |')
  console.log('==================================')
  console.log('|  1. Play with a friend         |')
  console.log('|  2. Play with the computer     |')
  console.log('|  3. Quit                       |')
  console.log('==================================')
  console.log('\n')
}
// function that displays choices regarding who wants to play  first between human and computer
function ChooseCompOrHuman () {
  console.log('\n')
  console.log('==================================')
  console.log('|        Who plays first!        |')
  console.log('==================================')
  console.log('|  1. Human plays first          |')
  console.log('|  2. Computer plays first       |')
  console.log('|  3. Return to Game             |')
  console.log('==================================')
  console.log('\n')
}

// function that switch players
function SwitchPlayer () {
  do {
    ChooseCompOrHuman()
    var actionNumber = readlineSync.questionInt('Please select a number : ')
    switch (actionNumber) {
      case 1:
        PlayWithComputer1()
        break
      case 2:
        PlayWithComputer2()
        break
      case 3:
        GameStart()
        break
      default:
        console.log('Invalid, enter number choice again!')
        break
    }
  } while (actionNumber !== 3)
}
// function to play the game
function PlayGame () {
  do {
    GameStart()
    var actionNumber = readlineSync.questionInt('Please select a number : ')
    switch (actionNumber) {
      case 1:
        PlayWithFriend()
        break
      case 2:
        SwitchPlayer()
        break
      case 3:
        break
      default:
        console.log('Invalid, enter number choice again!')
        break
    }
  } while (actionNumber !== 3)
}

PlayGame()
